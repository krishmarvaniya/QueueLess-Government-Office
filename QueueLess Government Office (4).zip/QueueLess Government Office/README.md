# 🏛️ QueueLess Government Office

> **Skip the Queue. Save Your Time.**

A modern, production-ready, full-stack digital government service platform featuring remote virtual token generation, real-time WebSocket queue updates, machine-learning-powered waiting time predictions, verifiable QR code passes, and dedicated portals for Citizens, Desk Officers, and Administrators.

---

## 🌟 Key Features

1. **Remote Virtual Token Generation**:
   - Citizens register and request virtual tokens remotely without physical queuing.
   - FIFO sequential numbering (e.g., `CERT-104`, `INC-105`) with duplicate active token prevention.
   - Operating hours enforcement to respect office work shifts.
2. **AI & Machine Learning Waiting-Time Prediction**:
   - Scikit-learn `RandomForestRegressor` model predicting dynamic waiting times based on queue depth, active counters, service durations, and time-of-day features.
   - Automatic multi-tier fallback to `LinearRegression` and closed-form queue mathematical formulas.
   - Automatic recommended arrival window incorporating a configurable 10-minute safety buffer.
3. **Real-Time WebSocket Queue Synchronization**:
   - Built on Flask-SocketIO.
   - Instantaneous updates for token calling, position shifts, and desk counter changes across all client devices without manual browser refresh.
4. **Verifiable QR Code Digital Passes**:
   - Generates high-resolution verification QR codes for entrance kiosks and counter verification scanners.
   - Printable and downloadable passes.
5. **Role-Based Portals**:
   - **Citizen Portal**: Dashboard, take token, token pass, real-time queue tracker, token history, notification inbox, and profile.
   - **Officer Desk Terminal**: Now Serving display, Call Next, Complete Service, Skip, Recall, and counter management.
   - **Admin Command Center**: Executive KPI cards, Chart.js visualizations, office management, services directory, counters, user accounts, and immutable audit logs.
6. **Executive Reporting**:
   - Daily, weekly, and monthly performance reports with instant CSV exports.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | HTML5, CSS3, JavaScript (ES6+), Bootstrap 5, Bootstrap Icons, Chart.js, Socket.IO Client |
| **Backend** | Python 3, Flask, Flask-SQLAlchemy, Flask-SocketIO, Flask-CORS, PyMySQL, Werkzeug, python-dotenv |
| **Database** | MySQL / MariaDB 10.4+ |
| **Machine Learning** | Scikit-learn (`RandomForestRegressor`), Pandas, NumPy, Scipy, Joblib |
| **QR Generation** | Python `qrcode`, Pillow |
| **Testing** | Pytest |
| **Containerization** | Docker, Docker Compose |

---

## 📂 Project Structure

```text
QueueLess-Government-Office/
├── backend/
│   ├── app.py                      # Application factory & Socket.IO server
│   ├── config.py                   # Centralized configuration
│   ├── extensions.py               # SQLAlchemy, SocketIO, CORS singletons
│   ├── requirements.txt            # Python dependencies
│   ├── .env.example                # Template configuration
│   ├── models/                     # SQLAlchemy Models
│   │   ├── user.py, office.py, service.py, counter.py, token.py, notification.py, prediction.py, audit_log.py
│   ├── routes/                     # REST API Blueprints
│   │   ├── auth.py, offices.py, services.py, tokens.py, queue.py, officer.py, admin.py, prediction.py, notifications.py, reports.py
│   ├── services/                   # Business Logic & Algorithms
│   │   ├── queue_service.py, token_service.py, prediction_service.py, notification_service.py, qr_service.py
│   ├── utils/                      # Auth, validators, and decorators
│   │   ├── auth.py, validators.py, decorators.py
│   └── prediction/                 # Model artifacts & predictor
│       ├── train_model.py, predictor.py, model.pkl
├── frontend/
│   ├── index.html, about.html, services.html, contact.html, login.html, register.html
│   ├── citizen/                    # Citizen portal pages
│   ├── officer/                    # Officer calling terminal pages
│   ├── admin/                      # Admin analytics & management pages
│   ├── css/                        # Custom styling & responsive layouts
│   ├── js/                         # Modular API client, auth, socket & role handlers
│   └── assets/                     # Generated QR codes & static assets
├── database/
│   ├── schema.sql                  # MySQL database tables DDL
│   └── seed.sql                    # Production demo seed data
├── ml/
│   ├── generate_data.py            # Historical queue synthetic generator
│   ├── dataset.csv                 # 2,500 sample training dataset
│   └── train_model.py              # ML training pipeline
├── docs/                           # Architecture, DB, API, testing & deployment docs
├── tests/                          # Automated Pytest test suite
├── Dockerfile                      # Production multi-stage container
├── docker-compose.yml              # Multi-container orchestration (App + MySQL)
├── DEPLOYMENT.md
└── README.md
```

---

## 🔑 Demo Credentials

> **Notice:** Demo credentials are provided for development and review only. Change all default passwords prior to production deployment.

| Role | Email | Password | Access Portal |
|---|---|---|---|
| **Administrator** | `admin@example.com` | `Admin@123` | `/admin/dashboard.html` |
| **Desk Officer** | `officer@example.com` | `Officer@123` | `/officer/dashboard.html` |
| **Senior Officer**| `officer2@example.com` | `Officer@123` | `/officer/dashboard.html` |
| **Citizen** | `citizen@example.com` | `Citizen@123` | `/citizen/dashboard.html` |
| **Citizen 2** | `citizen2@example.com` | `Citizen@123` | `/citizen/dashboard.html` |

*Quick login buttons are also provided on `/login.html` to auto-fill these demo accounts with a single click.*

---

## 🚀 Running the Application Locally

### 1. Prerequisites
- Python 3.10+ (tested on Python 3.14)
- MySQL / MariaDB (e.g. via XAMPP or native service)

### 2. Database Setup
Ensure MySQL is running on `127.0.0.1:3306`:
```sql
CREATE DATABASE IF NOT EXISTS queueless CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
Import schema and seed data:
```bash
mysql -u root queueless < database/schema.sql
mysql -u root queueless < database/seed.sql
```

### 3. Install Dependencies & Train ML Model
```bash
pip install -r backend/requirements.txt
python ml/train_model.py
```

### 4. Start the Application Server
```bash
python backend/app.py
```
Open your web browser and visit: **`http://127.0.0.1:5000`**

---

## 🐳 Docker Deployment

To launch the complete stack with an isolated MySQL 8.0 container:
```bash
docker-compose up -d --build
```
Access at **`http://localhost:5000`**.

---

## 🧪 Automated Testing

Execute the automated test suite with:
```bash
python -m pytest tests/test_full_suite.py -v
```

---

## 📄 License
Released under the [MIT License](file:///d:/QueueLess%20Government%20Office/LICENSE).
