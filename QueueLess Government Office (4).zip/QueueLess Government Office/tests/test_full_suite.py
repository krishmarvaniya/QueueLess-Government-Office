import pytest
import os
import json
from backend.app import create_app
from backend.config import TestConfig
from backend.extensions import db
from backend.models.user import User
from backend.models.office import Office
from backend.models.service import Service
from backend.models.counter import Counter
from backend.models.token import Token
from backend.prediction.predictor import predict_wait_time

@pytest.fixture(scope='module')
def test_app():
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()

        # Seed minimal fixtures
        admin = User(full_name="Admin Test", email="admin_test@test.com", mobile="1234567890", role="admin")
        admin.set_password("Admin@123")

        officer = User(full_name="Officer Test", email="officer_test@test.com", mobile="1234567891", role="officer")
        officer.set_password("Officer@123")

        citizen = User(full_name="Citizen Test", email="citizen_test@test.com", mobile="1234567892", role="citizen")
        citizen.set_password("Citizen@123")

        db.session.add_all([admin, officer, citizen])
        db.session.commit()

        office = Office(name="Test Office", code="TST", address="123 Civic St", city="Delhi", state="Delhi")
        db.session.add(office)
        db.session.commit()

        service = Service(office_id=office.id, name="Test Service", code="SRV", average_service_time=15)
        counter = Counter(office_id=office.id, counter_number="Counter 1", assigned_officer_id=officer.id)
        db.session.add_all([service, counter])
        db.session.commit()

        yield app

        db.session.remove()
        db.drop_all()

@pytest.fixture
def client(test_app):
    return test_app.test_client()

# ================= 1. AUTHENTICATION TESTS =================
def test_health_check(client):
    res = client.get('/api/health')
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    assert data['status'] == 'healthy'

def test_user_registration(client):
    payload = {
        'full_name': 'New Citizen',
        'email': 'newcitizen@test.com',
        'mobile': '+91 9999999999',
        'password': 'Password@123',
        'role': 'citizen'
    }
    res = client.post('/api/auth/register', json=payload)
    assert res.status_code == 201
    data = res.get_json()
    assert data['success'] is True
    assert 'token' in data['data']
    assert data['data']['user']['email'] == 'newcitizen@test.com'

def test_login_success(client):
    res = client.post('/api/auth/login', json={'email': 'citizen_test@test.com', 'password': 'Citizen@123'})
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    assert 'token' in data['data']

def test_login_invalid_password(client):
    res = client.post('/api/auth/login', json={'email': 'citizen_test@test.com', 'password': 'WrongPassword'})
    assert res.status_code == 401
    data = res.get_json()
    assert data['success'] is False

# ================= 2. TOKEN & QUEUE TESTS =================
def test_create_and_manage_token(client, test_app):
    # Login as citizen
    login_res = client.post('/api/auth/login', json={'email': 'citizen_test@test.com', 'password': 'Citizen@123'})
    token_str = login_res.get_json()['data']['token']
    headers = {'Authorization': f'Bearer {token_str}'}

    with test_app.app_context():
        office = Office.query.filter_by(code="TST").first()
        service = Service.query.filter_by(code="SRV").first()
        counter = Counter.query.filter_by(counter_number="Counter 1").first()

    # Create virtual token
    token_res = client.post('/api/tokens', json={
        'office_id': office.id,
        'service_id': service.id
    }, headers=headers)

    assert token_res.status_code == 201
    tok_data = token_res.get_json()['data']
    token_id = tok_data['id']
    token_number = tok_data['token_number']
    assert tok_data['status'] == 'WAITING'
    assert tok_data['queue_position'] == 1

    # Test duplicate prevention (cannot take another active token for same service)
    dup_res = client.post('/api/tokens', json={
        'office_id': office.id,
        'service_id': service.id
    }, headers=headers)
    assert dup_res.status_code == 400
    assert "already have an active token" in dup_res.get_json()['message']

    # Public Verification endpoint
    verify_res = client.get(f'/api/tokens/verify/{token_number}')
    assert verify_res.status_code == 200
    assert verify_res.get_json()['data']['token_number'] == token_number
    assert verify_res.get_json()['data']['is_valid'] is True

    # Login as officer to call next
    off_login = client.post('/api/auth/login', json={'email': 'officer_test@test.com', 'password': 'Officer@123'})
    off_token = off_login.get_json()['data']['token']
    off_headers = {'Authorization': f'Bearer {off_token}'}

    # Officer calls next
    call_res = client.post('/api/officer/next', json={'counter_id': counter.id}, headers=off_headers)
    assert call_res.status_code == 200
    called_tok = call_res.get_json()['data']
    assert called_tok['id'] == token_id
    assert called_tok['status'] == 'SERVING'

    # Officer completes token
    comp_res = client.post(f'/api/officer/token/{token_id}/complete', json={}, headers=off_headers)
    assert comp_res.status_code == 200
    assert comp_res.get_json()['data']['status'] == 'COMPLETED'

# ================= 3. ML PREDICTION TESTS =================
def test_prediction_engine():
    # Test closed-form and ML predictions
    pred = predict_wait_time(
        queue_length=5,
        people_ahead=4,
        active_counters=2,
        average_service_time=15
    )
    assert 'predicted_wait_minutes' in pred
    assert pred['predicted_wait_minutes'] > 0
    assert pred['features']['people_ahead'] == 4

def test_prediction_zero_queue():
    pred = predict_wait_time(
        queue_length=0,
        people_ahead=0,
        active_counters=2,
        average_service_time=15
    )
    assert pred['predicted_wait_minutes'] == 0.0

# ================= 4. SECURITY & RBAC TESTS =================
def test_unauthorized_admin_access(client):
    # Citizen trying to access admin endpoint
    login_res = client.post('/api/auth/login', json={'email': 'citizen_test@test.com', 'password': 'Citizen@123'})
    token_str = login_res.get_json()['data']['token']
    headers = {'Authorization': f'Bearer {token_str}'}

    res = client.get('/api/admin/users', headers=headers)
    assert res.status_code == 403
    assert res.get_json()['error'] == 'FORBIDDEN'
