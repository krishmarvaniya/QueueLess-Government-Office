/* ===================================================
   QueueLess Government Office - Officer Operations
   =================================================== */

const OfficerApp = {
    currentStatus: null,

    async init() {
        SocketManager.init();
        await this.loadStatus();

        // Listen for global queue events
        if (SocketManager.socket) {
            SocketManager.socket.on('queue_update', (snapshot) => {
                if (this.currentStatus && this.currentStatus.counter && snapshot.office_id === this.currentStatus.counter.office_id) {
                    this.loadStatus(false);
                }
            });
        }
    },

    async loadStatus(showLoading = true) {
        try {
            const res = await API.get('/officer/status');
            if (res.success && res.data) {
                this.currentStatus = res.data;
                this.renderDashboard(res.data);
                if (res.data.counter) {
                    SocketManager.joinOfficeRoom(res.data.counter.office_id);
                }
            }
        } catch (err) {
            showToast('error', 'Error', 'Failed to load officer terminal status');
        }
    },

    renderDashboard(data) {
        const counter = data.counter;
        const currentToken = data.current_token;
        const nextToken = data.next_token;

        // Counter info
        const counterNameEl = document.getElementById('officer-counter-name');
        if (counterNameEl) {
            counterNameEl.textContent = counter ? `${counter.counter_number} (${counter.office_name})` : 'Unassigned';
        }

        // Stats
        const waitingCountEl = document.getElementById('officer-waiting-count');
        if (waitingCountEl) waitingCountEl.textContent = data.waiting_count;

        const avgServiceEl = document.getElementById('officer-avg-service');
        if (avgServiceEl) avgServiceEl.textContent = `${data.average_service_time} min`;

        const completedTodayEl = document.getElementById('officer-completed-count');
        if (completedTodayEl) completedTodayEl.textContent = data.completed_today_count;

        // Serving Card
        const servingBox = document.getElementById('officer-serving-box');
        if (servingBox) {
            if (currentToken) {
                servingBox.innerHTML = `
                    <div class="officer-control-box fade-in">
                        <span class="badge bg-success px-3 py-2 mb-2">NOW SERVING</span>
                        <div class="officer-serving-number">${escapeHtml(currentToken.token_number)}</div>
                        <h4 class="text-white mb-1">${escapeHtml(currentToken.citizen_name || 'Citizen')}</h4>
                        <div class="text-info mb-3">Service: ${escapeHtml(currentToken.service_name)}</div>
                        
                        <div class="officer-actions-grid">
                            <button class="btn btn-success btn-lg" onclick="OfficerApp.completeToken(${currentToken.id})">
                                <i class="bi bi-check-circle me-1"></i> COMPLETE
                            </button>
                            <button class="btn btn-warning btn-lg text-dark" onclick="OfficerApp.recallToken(${currentToken.id})">
                                <i class="bi bi-volume-up me-1"></i> RECALL
                            </button>
                            <button class="btn btn-secondary btn-lg" onclick="OfficerApp.skipToken(${currentToken.id})">
                                <i class="bi bi-arrow-right-circle me-1"></i> SKIP
                            </button>
                        </div>
                    </div>
                `;
            } else {
                servingBox.innerHTML = `
                    <div class="officer-control-box fade-in bg-dark">
                        <span class="badge bg-secondary px-3 py-2 mb-2">COUNTER IDLE</span>
                        <div class="officer-serving-number text-muted">---</div>
                        <p class="text-muted">No token is currently being served at your counter.</p>
                        
                        <div class="mt-3">
                            <button class="btn btn-primary btn-lg px-4" id="btn-call-next" onclick="OfficerApp.callNext()">
                                <i class="bi bi-megaphone me-1"></i> CALL NEXT TOKEN
                            </button>
                        </div>
                    </div>
                `;
            }
        }

        // Next token in queue preview
        const nextPreviewEl = document.getElementById('officer-next-preview');
        if (nextPreviewEl) {
            if (nextToken) {
                nextPreviewEl.innerHTML = `
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-bold fs-5 text-primary">${escapeHtml(nextToken.token_number)}</div>
                            <small class="text-muted">${escapeHtml(nextToken.service_name)} (${escapeHtml(nextToken.citizen_name || 'Citizen')})</small>
                        </div>
                        <span class="badge bg-warning text-dark">Position #1</span>
                    </div>
                `;
            } else {
                nextPreviewEl.innerHTML = `<span class="text-muted">Queue is currently empty.</span>`;
            }
        }
    },

    async callNext() {
        const btn = document.getElementById('btn-call-next');
        setButtonLoading(btn, true, 'Calling Next...');
        try {
            const res = await API.post('/officer/next', {});
            if (res.success && res.data) {
                showToast('success', 'Token Called', `Token ${res.data.token_number} called to your counter!`);
                await this.loadStatus(false);
            }
        } catch (err) {
            showToast('error', 'Unable to Call', err.message || 'Error calling next token');
        } finally {
            setButtonLoading(btn, false);
        }
    },

    async completeToken(tokenId) {
        if (!confirm('Mark service as COMPLETED for this token?')) return;
        try {
            const res = await API.post(`/officer/token/${tokenId}/complete`, {});
            if (res.success) {
                showToast('success', 'Completed', `Token marked as completed.`);
                await this.loadStatus(false);
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to complete token');
        }
    },

    async skipToken(tokenId) {
        if (!confirm('Are you sure you want to SKIP this token?')) return;
        try {
            const res = await API.post(`/officer/token/${tokenId}/skip`, {});
            if (res.success) {
                showToast('warning', 'Skipped', `Token marked as skipped.`);
                await this.loadStatus(false);
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to skip token');
        }
    },

    async recallToken(tokenId) {
        try {
            const res = await API.post(`/officer/token/${tokenId}/recall`, {});
            if (res.success) {
                showToast('info', 'Token Recalled', `Token re-announced across display boards.`);
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to recall token');
        }
    }
};
