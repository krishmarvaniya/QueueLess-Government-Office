/* ===================================================
   QueueLess Government Office - Notifications Handler
   =================================================== */

const NotificationsApp = {
    async init() {
        await this.loadNotifications();
    },

    async loadNotifications() {
        try {
            const res = await API.get('/notifications');
            if (res.success && res.data) {
                this.renderList(res.data.notifications);
                this.updateBadge(res.data.unread_count);
            }
        } catch (err) {
            console.error('Failed to load notifications:', err);
        }
    },

    updateBadge(unreadCount) {
        const badge = document.querySelector('.notification-count-badge');
        if (badge) {
            if (unreadCount > 0) {
                badge.textContent = unreadCount;
                badge.style.display = 'inline-block';
            } else {
                badge.style.display = 'none';
            }
        }
    },

    renderList(notifications) {
        const container = document.getElementById('notifications-list-container');
        if (!container) return;

        if (!notifications || notifications.length === 0) {
            container.innerHTML = `
                <div class="card p-4 text-center text-muted">
                    <i class="bi bi-bell-slash fs-2 mb-2"></i>
                    <p>No notifications yet.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = notifications.map(n => `
            <div class="card mb-2 ${n.is_read ? 'opacity-75' : 'border-primary'}" id="notif-card-${n.id}">
                <div class="card-body p-3 d-flex align-items-start justify-content-between gap-3">
                    <div class="d-flex align-items-start gap-3">
                        <div class="mt-1">
                            <i class="bi ${n.type === 'success' ? 'bi-check-circle-fill text-success' : n.type === 'warning' ? 'bi-exclamation-triangle-fill text-warning' : n.type === 'alert' ? 'bi-exclamation-octagon-fill text-danger' : 'bi-info-circle-fill text-primary'} fs-4"></i>
                        </div>
                        <div>
                            <div class="fw-bold text-dark">${escapeHtml(n.title)}</div>
                            <div class="text-secondary small mb-1">${escapeHtml(n.message)}</div>
                            <small class="text-muted">${formatDateTime(n.created_at)}</small>
                        </div>
                    </div>
                    ${!n.is_read ? `
                        <button class="btn btn-sm btn-outline-secondary" onclick="NotificationsApp.markRead(${n.id})">
                            <i class="bi bi-check2"></i> Mark read
                        </button>
                    ` : ''}
                </div>
            </div>
        `).join('');
    },

    async markRead(id) {
        try {
            const res = await API.put(`/notifications/${id}/read`, {});
            if (res.success) {
                const card = document.getElementById(`notif-card-${id}`);
                if (card) {
                    card.classList.add('opacity-75');
                    card.classList.remove('border-primary');
                    const btn = card.querySelector('button');
                    if (btn) btn.remove();
                }
                const badge = document.querySelector('.notification-count-badge');
                if (badge) {
                    let c = parseInt(badge.textContent || '1') - 1;
                    this.updateBadge(Math.max(0, c));
                }
            }
        } catch (err) {
            showToast('error', 'Error', 'Failed to mark notification as read');
        }
    },

    async markAllRead() {
        try {
            const res = await API.put('/notifications/read-all', {});
            if (res.success) {
                showToast('success', 'Done', 'All notifications marked as read.');
                this.loadNotifications();
            }
        } catch (err) {
            showToast('error', 'Error', 'Failed to mark all as read');
        }
    }
};
