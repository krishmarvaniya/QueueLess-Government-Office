/* ===================================================
   QueueLess Government Office - Admin Operations & Analytics
   =================================================== */

const AdminApp = {
    charts: {},

    async initDashboard() {
        try {
            const res = await API.get('/admin/analytics');
            if (res.success && res.data) {
                const data = res.data;

                // Render metrics
                document.getElementById('stat-total-citizens').textContent = data.total_citizens;
                document.getElementById('stat-active-officers').textContent = data.active_officers;
                document.getElementById('stat-active-offices').textContent = data.active_offices;
                document.getElementById('stat-today-tokens').textContent = data.today_tokens;
                document.getElementById('stat-waiting-tokens').textContent = data.waiting_tokens;
                document.getElementById('stat-completed-tokens').textContent = data.completed_tokens;
                document.getElementById('stat-avg-wait').textContent = `${data.average_wait_minutes}m`;
                document.getElementById('stat-avg-service').textContent = `${data.average_service_minutes}m`;

                // Render Charts if Chart.js loaded
                this.renderCharts(data);
            }
        } catch (err) {
            showToast('error', 'Error', 'Failed to load admin analytics');
        }
    },

    renderCharts(data) {
        if (typeof Chart === 'undefined') return;

        // 1. Status Breakdown Doughnut Chart
        const statusCtx = document.getElementById('chart-status-breakdown');
        if (statusCtx) {
            if (this.charts.status) this.charts.status.destroy();
            this.charts.status = new Chart(statusCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Completed', 'Waiting', 'Cancelled', 'Skipped'],
                    datasets: [{
                        data: [
                            data.completed_tokens,
                            data.waiting_tokens,
                            data.cancelled_tokens,
                            data.skipped_tokens
                        ],
                        backgroundColor: ['#16a34a', '#f59e0b', '#dc2626', '#64748b']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' } }
                }
            });
        }

        // 2. Service Popularity Bar Chart
        const serviceCtx = document.getElementById('chart-service-popularity');
        if (serviceCtx && data.service_popularity) {
            if (this.charts.service) this.charts.service.destroy();
            this.charts.service = new Chart(serviceCtx, {
                type: 'bar',
                data: {
                    labels: data.service_popularity.map(s => s.service_name),
                    datasets: [{
                        label: 'Total Tokens',
                        data: data.service_popularity.map(s => s.count),
                        backgroundColor: '#2563eb',
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
                }
            });
        }

        // 3. Hourly Queue Load Bar/Line Chart
        const hourlyCtx = document.getElementById('chart-hourly-load');
        if (hourlyCtx && data.hourly_distribution) {
            const hours = ['8 AM', '9 AM', '10 AM', '11 AM', '12 PM', '1 PM', '2 PM', '3 PM', '4 PM', '5 PM'];
            if (this.charts.hourly) this.charts.hourly.destroy();
            this.charts.hourly = new Chart(hourlyCtx, {
                type: 'line',
                data: {
                    labels: hours,
                    datasets: [{
                        label: 'Tokens Issued Today',
                        data: data.hourly_distribution,
                        borderColor: '#0f766e',
                        backgroundColor: 'rgba(15, 118, 110, 0.1)',
                        fill: true,
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
                }
            });
        }
    },

    // ---------------- Users Management ----------------
    async loadUsers() {
        try {
            const res = await API.get('/admin/users');
            const tbody = document.querySelector('#users-table tbody');
            if (tbody && res.success) {
                tbody.innerHTML = res.data.map(u => `
                    <tr>
                        <td>#${u.id}</td>
                        <td class="fw-semibold">${escapeHtml(u.full_name)}</td>
                        <td>${escapeHtml(u.email)}</td>
                        <td>${escapeHtml(u.mobile)}</td>
                        <td><span class="badge ${u.role === 'admin' ? 'bg-danger' : u.role === 'officer' ? 'bg-primary' : 'bg-secondary'} text-uppercase">${u.role}</span></td>
                        <td>${u.is_active ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-danger">Inactive</span>'}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-danger" onclick="AdminApp.deleteUser(${u.id})">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (e) {
            showToast('error', 'Error', 'Failed to load users');
        }
    },

    async deleteUser(userId) {
        if (!confirm('Are you sure you want to delete this user?')) return;
        try {
            const res = await API.delete(`/admin/users/${userId}`);
            if (res.success) {
                showToast('success', 'User Deleted', 'User deleted successfully.');
                this.loadUsers();
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to delete user');
        }
    },

    // ---------------- Offices Management ----------------
    async loadOffices() {
        try {
            const res = await API.get('/offices');
            const tbody = document.querySelector('#offices-table tbody');
            if (tbody && res.success) {
                tbody.innerHTML = res.data.map(o => `
                    <tr>
                        <td class="fw-bold">${escapeHtml(o.code)}</td>
                        <td>${escapeHtml(o.name)}</td>
                        <td>${escapeHtml(o.city)}, ${escapeHtml(o.state)}</td>
                        <td>${o.opening_time} - ${o.closing_time}</td>
                        <td>${o.is_active ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>'}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-danger" onclick="AdminApp.deleteOffice(${o.id})">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (e) {
            showToast('error', 'Error', 'Failed to load offices');
        }
    },

    async deleteOffice(officeId) {
        if (!confirm('Are you sure you want to delete this office and all related services/counters?')) return;
        try {
            const res = await API.delete(`/offices/${officeId}`);
            if (res.success) {
                showToast('success', 'Office Deleted', 'Office deleted successfully.');
                this.loadOffices();
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to delete office');
        }
    },

    // ---------------- Services Management ----------------
    async loadServices() {
        try {
            const res = await API.get('/services');
            const tbody = document.querySelector('#services-table tbody');
            if (tbody && res.success) {
                tbody.innerHTML = res.data.map(s => `
                    <tr>
                        <td class="fw-bold">${escapeHtml(s.code)}</td>
                        <td>${escapeHtml(s.name)}</td>
                        <td>${escapeHtml(s.office_name || 'N/A')}</td>
                        <td>${s.average_service_time} mins</td>
                        <td>${s.is_active ? '<span class="badge bg-success">Active</span>' : '<span class="badge bg-secondary">Inactive</span>'}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-danger" onclick="AdminApp.deleteService(${s.id})">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (e) {
            showToast('error', 'Error', 'Failed to load services');
        }
    },

    async deleteService(serviceId) {
        if (!confirm('Are you sure you want to delete this service?')) return;
        try {
            const res = await API.delete(`/services/${serviceId}`);
            if (res.success) {
                showToast('success', 'Service Deleted', 'Service deleted successfully.');
                this.loadServices();
            }
        } catch (err) {
            showToast('error', 'Error', err.message || 'Failed to delete service');
        }
    },

    // ---------------- Audit Logs ----------------
    async loadAuditLogs() {
        try {
            const res = await API.get('/admin/audit-logs');
            const tbody = document.querySelector('#audit-logs-table tbody');
            if (tbody && res.success) {
                tbody.innerHTML = res.data.map(l => `
                    <tr>
                        <td>#${l.id}</td>
                        <td><span class="badge bg-dark">${escapeHtml(l.action)}</span></td>
                        <td>${escapeHtml(l.entity_type)} ${l.entity_id ? '#' + l.entity_id : ''}</td>
                        <td>${escapeHtml(l.user_name)}</td>
                        <td class="small text-muted">${escapeHtml(l.details || '—')}</td>
                        <td class="small">${formatDateTime(l.created_at)}</td>
                    </tr>
                `).join('');
            }
        } catch (e) {
            showToast('error', 'Error', 'Failed to load audit logs');
        }
    }
};
