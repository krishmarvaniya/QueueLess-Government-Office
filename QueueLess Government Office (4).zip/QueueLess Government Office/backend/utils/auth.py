from itsdangerous import URLSafeTimedSerializer, SignatureExpired, BadSignature
from flask import current_app

def get_serializer():
    return URLSafeTimedSerializer(current_app.config['SECRET_KEY'])

def generate_auth_token(user_id: int, role: str, expires_sec: int = 604800) -> str:
    """Generate a signed authentication token valid for 7 days."""
    s = get_serializer()
    return s.dumps({'user_id': user_id, 'role': role})

def decode_auth_token(token: str, max_age: int = 604800):
    """Verify and decode signed authentication token."""
    s = get_serializer()
    try:
        data = s.loads(token, max_age=max_age)
        return data
    except (SignatureExpired, BadSignature):
        return None
