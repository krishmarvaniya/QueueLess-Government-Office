import re
from datetime import time

EMAIL_REGEX = r'^[a-zA-Z0-9.\-_]+@gmail\.com$'
PHONE_REGEX = r'^[6789]\d{9}$'

def validate_email(email: str) -> bool:
    if not email or not isinstance(email, str):
        return False
    return bool(re.match(EMAIL_REGEX, email.strip().lower()))

def validate_mobile(mobile: str) -> bool:
    if not mobile or not isinstance(mobile, str):
        return False
    return bool(re.match(PHONE_REGEX, mobile.strip()))

def validate_password(password: str) -> tuple[bool, str]:
    if not password:
        return False, "Password is required."
    if len(password) < 6 or len(password) > 8:
        return False, "Password must be 6-8 characters long."
    if ' ' in password:
        return False, "Password cannot contain spaces."
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least 1 uppercase letter."
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least 1 lowercase letter."
    if not re.search(r'[0-9]', password):
        return False, "Password must contain at least 1 number."
    if not re.search(r'[!@#$%^&*]', password):
        return False, "Password must contain at least 1 special character (!@#$%^&*)."
    return True, ""

def validate_required_fields(data: dict, required: list) -> list:
    """Returns missing field names."""
    if not isinstance(data, dict):
        return required
    missing = []
    for field in required:
        val = data.get(field)
        if val is None or (isinstance(val, str) and not val.strip()):
            missing.append(field)
    return missing

def parse_time_str(time_str: str) -> time | None:
    """Parse '09:00:00' or '09:00' to a datetime.time object."""
    try:
        parts = [int(p) for p in time_str.strip().split(':')]
        if len(parts) == 2:
            return time(parts[0], parts[1], 0)
        elif len(parts) == 3:
            return time(parts[0], parts[1], parts[2])
    except Exception:
        pass
    return None
