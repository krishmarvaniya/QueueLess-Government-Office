import os
import qrcode
from flask import current_app

def generate_token_qr(token_number: str) -> str:
    """Generate QR code for a given token number containing verification info."""
    qr_dir = current_app.config['UPLOAD_FOLDER']
    os.makedirs(qr_dir, exist_ok=True)
    
    file_name = f"qr_{token_number.replace('-', '_')}.png"
    file_path = os.path.join(qr_dir, file_name)
    
    # Payload contains public verification URL identifier (non-sensitive)
    verification_payload = f"/api/tokens/verify/{token_number}"
    
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=8,
        border=3,
    )
    qr.add_data(verification_payload)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="#1e293b", back_color="#ffffff")
    img.save(file_path)
    
    # Return relative web accessible path
    return f"/assets/qrcodes/{file_name}"
