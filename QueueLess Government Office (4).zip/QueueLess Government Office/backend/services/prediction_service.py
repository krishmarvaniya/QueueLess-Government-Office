from datetime import datetime, timedelta
from flask import current_app
from backend.extensions import db
from backend.models.prediction import PredictionHistory
from backend.models.counter import Counter
from backend.prediction.predictor import predict_wait_time

def calculate_token_prediction(token, people_ahead: int, queue_length: int, save_history: bool = True):
    """
    Calculate estimated waiting time and recommended arrival time for a token.
    """
    office_id = token.office_id
    service = token.service
    avg_service_time = service.average_service_time if service else 15

    # Count active counters for this office
    active_counters_count = Counter.query.filter_by(office_id=office_id, is_active=True).count()
    if active_counters_count == 0:
        active_counters_count = 1

    now = datetime.now()
    safety_buffer = current_app.config.get('SAFETY_BUFFER_MINUTES', 10)
    min_wait = current_app.config.get('MIN_WAITING_TIME_MINUTES', 3)

    pred_result = predict_wait_time(
        queue_length=queue_length,
        people_ahead=people_ahead,
        active_counters=active_counters_count,
        average_service_time=avg_service_time,
        hour=now.hour,
        day_of_week=now.weekday(),
        min_wait=min_wait
    )

    predicted_minutes = int(round(pred_result['predicted_wait_minutes']))

    # Recommended arrival calculation
    # Current time + wait time - buffer (cannot be in the past)
    arrival_time = now + timedelta(minutes=predicted_minutes) - timedelta(minutes=safety_buffer)
    if arrival_time < now:
        arrival_time = now

    token.estimated_wait_minutes = predicted_minutes
    token.recommended_arrival = arrival_time

    if save_history and token.id:
        try:
            history_record = PredictionHistory(
                token_id=token.id,
                queue_length=queue_length,
                people_ahead=people_ahead,
                active_counters=active_counters_count,
                average_service_time=avg_service_time,
                hour=now.hour,
                day_of_week=now.weekday(),
                predicted_wait=pred_result['predicted_wait_minutes']
            )
            db.session.add(history_record)
        except Exception as e:
            print(f"Error saving prediction history: {e}")

    return {
        'estimated_wait_minutes': predicted_minutes,
        'recommended_arrival': arrival_time.strftime('%I:%M %p'),
        'recommended_arrival_datetime': arrival_time.strftime('%Y-%m-%d %H:%M:%S'),
        'prediction_details': pred_result
    }
