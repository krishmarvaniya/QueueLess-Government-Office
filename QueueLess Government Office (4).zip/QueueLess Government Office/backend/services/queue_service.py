from datetime import datetime
from backend.extensions import db, socketio
from backend.models.token import Token
from backend.models.counter import Counter
from backend.models.prediction import PredictionHistory
from backend.models.audit_log import AuditLog
from backend.services.prediction_service import calculate_token_prediction
from backend.services.notification_service import (
    notify_queue_updated,
    notify_turn_approaching,
    notify_serving,
    notify_completed,
    notify_skipped
)

def emit_queue_updates(office_id: int):
    """Broadcast real-time queue snapshot to office room and general listeners."""
    try:
        snapshot = get_office_queue_summary(office_id)
        socketio.emit('queue_update', snapshot, room=f"office_{office_id}")
        socketio.emit('global_queue_update', snapshot)
    except Exception as e:
        print(f"Error emitting queue updates: {e}")

def get_office_queue_summary(office_id: int):
    """Retrieve active serving and waiting queue data for an office."""
    serving_tokens = Token.query.filter_by(
        office_id=office_id,
        status='SERVING'
    ).order_by(Token.called_at.desc()).all()

    waiting_tokens = Token.query.filter_by(
        office_id=office_id,
        status='WAITING'
    ).order_by(Token.issued_at.asc()).all()

    counters = Counter.query.filter_by(office_id=office_id, is_active=True).all()

    return {
        'office_id': office_id,
        'timestamp': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S'),
        'serving_count': len(serving_tokens),
        'waiting_count': len(waiting_tokens),
        'serving': [t.to_dict() for t in serving_tokens],
        'waiting': [t.to_dict() for t in waiting_tokens[:15]], # Top 15 waiting
        'counters': [c.to_dict() for c in counters]
    }

def recalculate_queue_positions(office_id: int, service_id: int = None):
    """
    Recalculate positions for all WAITING tokens and send approaching notifications.
    """
    query = Token.query.filter_by(office_id=office_id, status='WAITING')
    if service_id:
        query = query.filter_by(service_id=service_id)

    waiting_tokens = query.order_by(Token.issued_at.asc()).all()
    queue_length = len(waiting_tokens)

    for idx, tok in enumerate(waiting_tokens):
        people_ahead = idx
        pos = idx + 1
        prev_pos = tok.queue_position

        tok.queue_position = pos
        calculate_token_prediction(tok, people_ahead=people_ahead, queue_length=queue_length, save_history=False)

        # Notify if position improved significantly or approaching
        if prev_pos != pos:
            # Emit token-specific real-time update
            socketio.emit(f'token_{tok.id}', tok.to_dict())

            if people_ahead in [1, 2]:
                notify_turn_approaching(tok, people_ahead)
            elif pos % 3 == 0:
                notify_queue_updated(tok, people_ahead, pos)

    db.session.commit()
    emit_queue_updates(office_id)

def call_next_token(officer_user_id: int, counter_id: int, service_id: int = None):
    """
    Officer calls the next waiting token to their counter.
    """
    counter = Counter.query.get(counter_id)
    if not counter:
        return None, "Counter not found."

    office_id = counter.office_id

    # Complete or clear any currently serving token at this counter
    current_serving = Token.query.filter_by(
        counter_id=counter_id,
        status='SERVING'
    ).first()
    if current_serving:
        return None, f"Counter {counter.counter_number} is already serving token {current_serving.token_number}. Please complete or skip it first."

    # Find next WAITING token (FIFO)
    query = Token.query.filter_by(office_id=office_id, status='WAITING')
    if service_id:
        query = query.filter_by(service_id=service_id)

    next_token = query.order_by(Token.issued_at.asc()).first()
    if not next_token:
        return None, "No tokens are currently waiting in the queue."

    # Update token status
    next_token.status = 'SERVING'
    next_token.counter_id = counter_id
    next_token.called_at = datetime.utcnow()
    next_token.queue_position = 0

    # Calculate actual waiting time from issue to call
    if next_token.issued_at:
        wait_seconds = (next_token.called_at - next_token.issued_at).total_seconds()
        actual_wait_mins = round(wait_seconds / 60.0, 1)
        # Update matching prediction record if present
        pred_history = PredictionHistory.query.filter_by(token_id=next_token.id).first()
        if pred_history:
            pred_history.actual_wait = actual_wait_mins

    # Audit Log
    audit = AuditLog(
        user_id=officer_user_id,
        action='TOKEN_CALLED',
        entity_type='TOKEN',
        entity_id=next_token.id,
        details=f"Token {next_token.token_number} called to {counter.counter_number}"
    )
    db.session.add(audit)

    # Notify Citizen
    notify_serving(next_token, counter.counter_number)

    db.session.commit()

    # Recalculate remaining waiting tokens
    recalculate_queue_positions(office_id, next_token.service_id)

    # Emit broadcast for display boards and audio announcements
    announcement_data = {
        'token_number': next_token.token_number,
        'counter_number': counter.counter_number,
        'service_name': next_token.service.name,
        'office_name': next_token.office.name,
        'token': next_token.to_dict()
    }
    socketio.emit('call_announcement', announcement_data, room=f"office_{office_id}")
    socketio.emit(f'token_{next_token.id}', next_token.to_dict())

    return next_token, None

def complete_current_token(token_id: int, officer_user_id: int):
    """
    Officer completes service for a token.
    """
    token = Token.query.get(token_id)
    if not token:
        return None, "Token not found."

    if token.status != 'SERVING':
        return None, f"Token cannot be completed because its status is {token.status}."

    token.status = 'COMPLETED'
    token.completed_at = datetime.utcnow()

    audit = AuditLog(
        user_id=officer_user_id,
        action='TOKEN_COMPLETED',
        entity_type='TOKEN',
        entity_id=token.id,
        details=f"Token {token.token_number} marked COMPLETED."
    )
    db.session.add(audit)

    notify_completed(token)
    db.session.commit()

    socketio.emit(f'token_{token.id}', token.to_dict())
    emit_queue_updates(token.office_id)
    return token, None

def skip_current_token(token_id: int, officer_user_id: int):
    """
    Officer skips a token if citizen didn't show up.
    """
    token = Token.query.get(token_id)
    if not token:
        return None, "Token not found."

    if token.status not in ['WAITING', 'SERVING']:
        return None, f"Token cannot be skipped because its status is {token.status}."

    office_id = token.office_id
    service_id = token.service_id
    token.status = 'SKIPPED'
    token.counter_id = None

    audit = AuditLog(
        user_id=officer_user_id,
        action='TOKEN_SKIPPED',
        entity_type='TOKEN',
        entity_id=token.id,
        details=f"Token {token.token_number} marked SKIPPED."
    )
    db.session.add(audit)

    notify_skipped(token)
    db.session.commit()

    recalculate_queue_positions(office_id, service_id)
    socketio.emit(f'token_{token.id}', token.to_dict())
    return token, None

def recall_current_token(token_id: int, officer_user_id: int):
    """
    Officer re-announces a currently serving token.
    """
    token = Token.query.get(token_id)
    if not token:
        return None, "Token not found."

    if token.status != 'SERVING':
        return None, "Only currently serving tokens can be recalled."

    counter_number = token.counter.counter_number if token.counter else "Officer Counter"

    audit = AuditLog(
        user_id=officer_user_id,
        action='TOKEN_RECALLED',
        entity_type='TOKEN',
        entity_id=token.id,
        details=f"Token {token.token_number} re-announced at {counter_number}."
    )
    db.session.add(audit)
    db.session.commit()

    announcement_data = {
        'token_number': token.token_number,
        'counter_number': counter_number,
        'service_name': token.service.name,
        'office_name': token.office.name,
        'token': token.to_dict(),
        'is_recall': True
    }
    socketio.emit('call_announcement', announcement_data, room=f"office_{token.office_id}")
    return token, None

def cancel_user_token(token_id: int, user_id: int):
    """
    Citizen cancels their waiting token.
    """
    token = Token.query.get(token_id)
    if not token:
        return None, "Token not found."

    if token.user_id != user_id:
        return None, "Unauthorized: you do not own this token."

    if token.status != 'WAITING':
        return None, f"Cannot cancel token with status '{token.status}'."

    office_id = token.office_id
    service_id = token.service_id
    token.status = 'CANCELLED'
    token.cancelled_at = datetime.utcnow()

    audit = AuditLog(
        user_id=user_id,
        action='TOKEN_CANCELLED',
        entity_type='TOKEN',
        entity_id=token.id,
        details=f"Citizen cancelled token {token.token_number}."
    )
    db.session.add(audit)
    db.session.commit()

    recalculate_queue_positions(office_id, service_id)
    socketio.emit(f'token_{token.id}', token.to_dict())
    return token, None
