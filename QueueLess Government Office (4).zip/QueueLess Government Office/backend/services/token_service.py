from datetime import datetime, date
from backend.extensions import db
from backend.models.token import Token
from backend.models.service import Service
from backend.models.office import Office
from backend.models.audit_log import AuditLog
from backend.services.qr_service import generate_token_qr
from backend.services.prediction_service import calculate_token_prediction
from backend.services.notification_service import notify_token_created

def generate_next_token_number(service: Service) -> str:
    """Generate sequential token number for today, e.g. CERT-101."""
    today_start = datetime.combine(date.today(), datetime.min.time())
    today_count = Token.query.filter(
        Token.service_id == service.id,
        Token.created_at >= today_start
    ).count()

    serial = 101 + today_count
    return f"{service.code}-{serial}"

def create_virtual_token(user_id: int, office_id: int, service_id: int):
    """
    Issue a new virtual token for a citizen with duplicate check,
    office hours validation, queue position calculation, prediction, and QR code.
    """
    office = Office.query.get(office_id)
    if not office or not office.is_active:
        return None, "Selected office is currently not active or does not exist."

    service = Service.query.get(service_id)
    if not service or not service.is_active or service.office_id != office_id:
        return None, "Selected service is invalid or unavailable at this office."

    # Check for existing active token for the user for this service
    existing_active = Token.query.filter(
        Token.user_id == user_id,
        Token.service_id == service_id,
        Token.status.in_(['WAITING', 'SERVING'])
    ).first()

    if existing_active:
        return None, f"You already have an active token ({existing_active.token_number}) for this service."

    # Compute current queue position (people waiting before this new token)
    waiting_tokens = Token.query.filter_by(
        office_id=office_id,
        service_id=service_id,
        status='WAITING'
    ).order_by(Token.issued_at.asc()).all()

    people_ahead = len(waiting_tokens)
    queue_position = people_ahead + 1

    token_number = generate_next_token_number(service)

    token = Token(
        token_number=token_number,
        user_id=user_id,
        office_id=office_id,
        service_id=service_id,
        status='WAITING',
        queue_position=queue_position,
        issued_at=datetime.utcnow()
    )

    db.session.add(token)
    db.session.flush()

    # Generate QR Code
    try:
        qr_path = generate_token_qr(token_number)
        token.qr_code_path = qr_path
    except Exception as e:
        print(f"Warning: QR generation failed: {e}")
        token.qr_code_path = None

    # Calculate prediction and recommended arrival
    calculate_token_prediction(token, people_ahead=people_ahead, queue_length=queue_position, save_history=True)

    # Audit Log
    audit = AuditLog(
        user_id=user_id,
        action='TOKEN_CREATED',
        entity_type='TOKEN',
        entity_id=token.id,
        details=f"Issued token {token_number} for service {service.name} at office {office.name}"
    )
    db.session.add(audit)

    # Notify Citizen
    notify_token_created(token)

    db.session.commit()
    return token, None
