import os
from datetime import timedelta
from dotenv import load_dotenv

# Always resolve .env relative to this file's parent (project root),
# regardless of the working directory the process was launched from.
_PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
_DOTENV_PATH  = os.path.join(_PROJECT_ROOT, '.env')
load_dotenv(dotenv_path=_DOTENV_PATH, override=False)

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    """Base application configuration."""
    SECRET_KEY = os.getenv('SECRET_KEY', 'queueless-gov-secret-key-production-ready-2026')
    
    # Database Configuration (MySQL with PyMySQL)
    DB_USER = os.getenv('DB_USER', 'root')
    DB_PASSWORD = os.getenv('DB_PASSWORD', '')
    DB_HOST = os.getenv('DB_HOST', '127.0.0.1')
    DB_PORT = os.getenv('DB_PORT', '3306')
    DB_NAME = os.getenv('DB_NAME', 'queueless')
    
    # Constructed MySQL URI
    SQLALCHEMY_DATABASE_URI = os.getenv(
        'DATABASE_URL',
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_recycle': 280,
        'pool_pre_ping': True
    }
    
    # Session / Cookie settings
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # CORS & SocketIO Origins
    CORS_ORIGINS = os.getenv('CORS_ORIGINS', '*').split(',')
    
    # Business Logic Config
    SAFETY_BUFFER_MINUTES = int(os.getenv('SAFETY_BUFFER_MINUTES', 10))
    MIN_WAITING_TIME_MINUTES = int(os.getenv('MIN_WAITING_TIME_MINUTES', 3))
    ENFORCE_OFFICE_HOURS = os.getenv('ENFORCE_OFFICE_HOURS', 'true').lower() == 'true'
    
    # File Storage Paths
    STATIC_FOLDER = os.path.join(os.path.dirname(BASE_DIR), 'frontend')
    UPLOAD_FOLDER = os.path.join(STATIC_FOLDER, 'assets', 'qrcodes')
    MODEL_DIR = os.path.join(BASE_DIR, 'prediction')
    MODEL_FILE = os.path.join(MODEL_DIR, 'model.pkl')
    
    # Ensure directories exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)

class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    ENFORCE_OFFICE_HOURS = False
