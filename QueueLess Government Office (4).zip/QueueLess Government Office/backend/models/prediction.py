from datetime import datetime
from backend.extensions import db

class PredictionHistory(db.Model):
    __tablename__ = 'prediction_history'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    token_id = db.Column(db.Integer, db.ForeignKey('tokens.id', ondelete='CASCADE'), nullable=True, index=True)
    queue_length = db.Column(db.Integer, nullable=False, default=0)
    people_ahead = db.Column(db.Integer, nullable=False, default=0)
    active_counters = db.Column(db.Integer, nullable=False, default=1)
    average_service_time = db.Column(db.Integer, nullable=False, default=15)
    hour = db.Column(db.Integer, nullable=False, default=10)
    day_of_week = db.Column(db.Integer, nullable=False, default=1)
    predicted_wait = db.Column(db.Float, nullable=False, default=0.0)
    actual_wait = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'token_id': self.token_id,
            'queue_length': self.queue_length,
            'people_ahead': self.people_ahead,
            'active_counters': self.active_counters,
            'average_service_time': self.average_service_time,
            'hour': self.hour,
            'day_of_week': self.day_of_week,
            'predicted_wait': round(self.predicted_wait, 1),
            'actual_wait': round(self.actual_wait, 1) if self.actual_wait is not None else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S') if self.created_at else None
        }
