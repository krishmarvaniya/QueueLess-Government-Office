from backend.extensions import db

class Counter(db.Model):
    __tablename__ = 'counters'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    office_id = db.Column(db.Integer, db.ForeignKey('offices.id', ondelete='CASCADE'), nullable=False, index=True)
    counter_number = db.Column(db.String(20), nullable=False)
    assigned_officer_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True, index=True)
    is_active = db.Column(db.Boolean, default=True, nullable=False)

    __table_args__ = (
        db.UniqueConstraint('office_id', 'counter_number', name='uk_office_counter'),
    )

    # Relationships
    tokens = db.relationship('Token', backref='counter', lazy='dynamic')

    def to_dict(self):
        return {
            'id': self.id,
            'office_id': self.office_id,
            'office_name': self.office.name if self.office else None,
            'counter_number': self.counter_number,
            'assigned_officer_id': self.assigned_officer_id,
            'officer_name': self.officer.full_name if self.officer else 'Unassigned',
            'is_active': self.is_active
        }
