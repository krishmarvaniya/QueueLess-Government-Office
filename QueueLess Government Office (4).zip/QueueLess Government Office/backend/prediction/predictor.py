import os
import joblib
from datetime import datetime

_cached_model = None

def get_model(model_path=None):
    global _cached_model
    if _cached_model is not None:
        return _cached_model

    if model_path is None:
        model_path = os.path.join(os.path.dirname(__file__), 'model.pkl')

    if os.path.exists(model_path):
        try:
            _cached_model = joblib.load(model_path)
            return _cached_model
        except Exception as e:
            print(f"Error loading model from {model_path}: {e}")
            return None
    return None

def predict_wait_time(
    queue_length: int,
    people_ahead: int,
    active_counters: int,
    average_service_time: int,
    hour: int = None,
    day_of_week: int = None,
    min_wait: int = 3
) -> dict:
    """
    Predict waiting time in minutes using ML model with mathematical fallback.
    """
    now = datetime.now()
    if hour is None:
        hour = now.hour
    if day_of_week is None:
        day_of_week = now.weekday()

    # Active counters must be at least 1 for calculation
    counters = max(1, active_counters)
    ahead = max(0, people_ahead)
    length = max(ahead, queue_length)
    avg_service = max(1, average_service_time)

    # 1. Mathematical calculation fallback
    math_wait = (ahead * avg_service) / counters
    if ahead > 0:
        math_wait = max(float(min_wait), math_wait)
    else:
        math_wait = 0.0

    model_payload = get_model()
    if model_payload and 'model' in model_payload:
        try:
            model = model_payload['model']
            features = [[length, ahead, counters, avg_service, hour, day_of_week]]
            ml_pred = float(model.predict(features)[0])
            if ahead == 0:
                ml_pred = 0.0
            else:
                ml_pred = max(float(min_wait), ml_pred)
            
            return {
                'predicted_wait_minutes': round(ml_pred, 1),
                'method': model_payload.get('model_name', 'RandomForestRegressor'),
                'is_ml': True,
                'math_fallback_minutes': round(math_wait, 1),
                'features': {
                    'queue_length': length,
                    'people_ahead': ahead,
                    'active_counters': counters,
                    'average_service_time': avg_service,
                    'hour': hour,
                    'day_of_week': day_of_week
                }
            }
        except Exception as e:
            print(f"ML prediction runtime error: {e}. Using mathematical fallback.")

    return {
        'predicted_wait_minutes': round(math_wait, 1),
        'method': 'Mathematical Queue Fallback',
        'is_ml': False,
        'math_fallback_minutes': round(math_wait, 1),
        'features': {
            'queue_length': length,
            'people_ahead': ahead,
            'active_counters': counters,
            'average_service_time': avg_service,
            'hour': hour,
            'day_of_week': day_of_week
        }
    }
