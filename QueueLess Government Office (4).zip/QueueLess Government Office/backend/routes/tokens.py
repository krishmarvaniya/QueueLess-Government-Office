from flask import Blueprint, request, g, current_app
from backend.models.token import Token
from backend.models.office import Office
from backend.services.token_service import create_virtual_token
from backend.services.queue_service import cancel_user_token
from backend.utils.decorators import success_response, error_response, login_required
from backend.utils.validators import validate_required_fields

tokens_bp = Blueprint('tokens', __name__, url_prefix='/api/tokens')

@tokens_bp.route('', methods=['POST'])
@login_required
def take_token():
    data = request.get_json() or {}
    missing = validate_required_fields(data, ['office_id', 'service_id'])
    if missing:
        return error_response(f"Missing required fields: {', '.join(missing)}", "VALIDATION_ERROR", 400)

    office_id = int(data['office_id'])
    service_id = int(data['service_id'])

    office = Office.query.get(office_id)
    if not office or not office.is_active:
        return error_response("Office is currently inactive or not found.", "OFFICE_UNAVAILABLE", 400)

    # Check Operating Hours
    enforce_hours = current_app.config.get('ENFORCE_OFFICE_HOURS', True)
    if enforce_hours and not office.is_open_now():
        open_str = office.opening_time.strftime('%I:%M %p') if office.opening_time else '09:00 AM'
        close_str = office.closing_time.strftime('%I:%M %p') if office.closing_time else '05:00 PM'
        return error_response(
            f"Office is currently closed. Operating hours: {open_str} - {close_str}.",
            "OFFICE_CLOSED",
            400,
            details={'opening_time': open_str, 'closing_time': close_str}
        )

    token, err = create_virtual_token(g.current_user.id, office_id, service_id)
    if err:
        return error_response(err, "TOKEN_CREATION_FAILED", 400)

    return success_response(token.to_dict(), "Virtual token generated successfully!", 201)

@tokens_bp.route('/my', methods=['GET'])
@login_required
def get_my_tokens():
    # Return active tokens and past tokens
    active_tokens = Token.query.filter(
        Token.user_id == g.current_user.id,
        Token.status.in_(['WAITING', 'SERVING'])
    ).order_by(Token.issued_at.desc()).all()

    past_tokens = Token.query.filter(
        Token.user_id == g.current_user.id,
        Token.status.in_(['COMPLETED', 'SKIPPED', 'CANCELLED'])
    ).order_by(Token.created_at.desc()).limit(30).all()

    return success_response({
        'active': [t.to_dict() for t in active_tokens],
        'history': [t.to_dict() for t in past_tokens]
    }, "Tokens retrieved", 200)

@tokens_bp.route('/<int:token_id>', methods=['GET'])
@login_required
def get_token(token_id):
    token = Token.query.get(token_id)
    if not token:
        return error_response("Token not found", "NOT_FOUND", 404)

    # Users can view their own tokens, officers and admins can view any
    if g.current_user.role == 'citizen' and token.user_id != g.current_user.id:
        return error_response("Unauthorized to view this token", "FORBIDDEN", 403)

    return success_response(token.to_dict(), "Token details retrieved", 200)

@tokens_bp.route('/<int:token_id>/cancel', methods=['POST'])
@login_required
def cancel_token(token_id):
    token, err = cancel_user_token(token_id, g.current_user.id)
    if err:
        return error_response(err, "CANCEL_FAILED", 400)

    return success_response(token.to_dict(), "Token has been successfully cancelled", 200)

@tokens_bp.route('/verify/<string:token_number>', methods=['GET'])
def verify_token(token_number):
    """
    Public verification endpoint for QR code scans.
    Returns non-sensitive verification details.
    """
    token = Token.query.filter_by(token_number=token_number).first()
    if not token:
        return error_response("Invalid token or token record not found.", "INVALID_TOKEN", 404)

    return success_response({
        'token_number': token.token_number,
        'office': token.office.name if token.office else None,
        'service': token.service.name if token.service else None,
        'status': token.status,
        'counter': token.counter.counter_number if token.counter else 'Pending',
        'issued_at': token.issued_at.strftime('%Y-%m-%d %I:%M %p') if token.issued_at else None,
        'is_valid': token.status in ['WAITING', 'SERVING']
    }, "Token verification details", 200)
