from flask import Blueprint
from backend.models.token import Token
from backend.services.queue_service import get_office_queue_summary
from backend.utils.decorators import success_response, error_response

queue_bp = Blueprint('queue', __name__, url_prefix='/api/queue')

@queue_bp.route('/<int:office_id>', methods=['GET'])
def get_office_queue(office_id):
    summary = get_office_queue_summary(office_id)
    return success_response(summary, "Office queue status retrieved", 200)

@queue_bp.route('/token/<int:token_id>', methods=['GET'])
def get_token_queue_status(token_id):
    token = Token.query.get(token_id)
    if not token:
        return error_response("Token not found", "NOT_FOUND", 404)

    # Calculate people ahead
    if token.status == 'WAITING':
        people_ahead = Token.query.filter(
            Token.office_id == token.office_id,
            Token.service_id == token.service_id,
            Token.status == 'WAITING',
            Token.issued_at < token.issued_at
        ).count()
        position = people_ahead + 1
    elif token.status == 'SERVING':
        people_ahead = 0
        position = 0
    else:
        people_ahead = 0
        position = 0

    current_serving = Token.query.filter_by(
        office_id=token.office_id,
        service_id=token.service_id,
        status='SERVING'
    ).order_by(Token.called_at.desc()).first()

    data = {
        'token': token.to_dict(),
        'queue_position': position,
        'people_ahead': people_ahead,
        'current_serving_token': current_serving.token_number if current_serving else "None",
        'current_serving_counter': current_serving.counter.counter_number if current_serving and current_serving.counter else None,
        'estimated_wait_minutes': token.estimated_wait_minutes,
        'recommended_arrival': token.recommended_arrival.strftime('%I:%M %p') if token.recommended_arrival else None
    }

    return success_response(data, "Token queue position retrieved", 200)
