from flask import Blueprint, request, g
from backend.extensions import db
from backend.models.service import Service
from backend.models.office import Office
from backend.models.audit_log import AuditLog
from backend.utils.decorators import success_response, error_response, roles_required
from backend.utils.validators import validate_required_fields

services_bp = Blueprint('services', __name__, url_prefix='/api/services')

@services_bp.route('', methods=['GET'])
def list_services():
    office_id = request.args.get('office_id', type=int)
    query = Service.query.filter_by(is_active=True)
    if office_id:
        query = query.filter_by(office_id=office_id)
    
    services = query.all()
    return success_response([s.to_dict() for s in services], "Services list retrieved", 200)

@services_bp.route('/<int:service_id>', methods=['GET'])
def get_service(service_id):
    service = Service.query.get(service_id)
    if not service:
        return error_response("Service not found", "NOT_FOUND", 404)
    return success_response(service.to_dict(), "Service details retrieved", 200)

@services_bp.route('', methods=['POST'])
@roles_required('admin')
def create_service():
    data = request.get_json() or {}
    missing = validate_required_fields(data, ['office_id', 'name', 'code'])
    if missing:
        return error_response(f"Missing required fields: {', '.join(missing)}", "VALIDATION_ERROR", 400)

    office = Office.query.get(data['office_id'])
    if not office:
        return error_response("Referenced office does not exist", "OFFICE_NOT_FOUND", 404)

    code = data['code'].strip().upper()
    existing = Service.query.filter_by(office_id=office.id, code=code).first()
    if existing:
        return error_response(f"Service with code '{code}' already exists for this office", "DUPLICATE_SERVICE", 409)

    service = Service(
        office_id=office.id,
        name=data['name'].strip(),
        code=code,
        description=data.get('description', '').strip(),
        average_service_time=int(data.get('average_service_time', 15)),
        is_active=bool(data.get('is_active', True))
    )
    db.session.add(service)
    db.session.commit()

    audit = AuditLog(user_id=g.current_user.id, action='SERVICE_CREATED', entity_type='SERVICE', entity_id=service.id, details=f"Created service {service.name} ({service.code})")
    db.session.add(audit)
    db.session.commit()

    return success_response(service.to_dict(), "Service created successfully", 201)

@services_bp.route('/<int:service_id>', methods=['PUT'])
@roles_required('admin')
def update_service(service_id):
    service = Service.query.get(service_id)
    if not service:
        return error_response("Service not found", "NOT_FOUND", 404)

    data = request.get_json() or {}
    if 'name' in data:
        service.name = data['name'].strip()
    if 'description' in data:
        service.description = data['description'].strip()
    if 'average_service_time' in data:
        service.average_service_time = int(data['average_service_time'])
    if 'is_active' in data:
        service.is_active = bool(data['is_active'])

    db.session.commit()
    return success_response(service.to_dict(), "Service updated successfully", 200)

@services_bp.route('/<int:service_id>', methods=['DELETE'])
@roles_required('admin')
def delete_service(service_id):
    service = Service.query.get(service_id)
    if not service:
        return error_response("Service not found", "NOT_FOUND", 404)

    db.session.delete(service)
    db.session.commit()
    return success_response(None, "Service deleted successfully", 200)
