from flask import Blueprint, request, g
from backend.extensions import db
from backend.models.counter import Counter
from backend.models.token import Token
from backend.services.queue_service import (
    call_next_token,
    complete_current_token,
    skip_current_token,
    recall_current_token
)
from backend.utils.decorators import success_response, error_response, roles_required

officer_bp = Blueprint('officer', __name__, url_prefix='/api/officer')

@officer_bp.route('/status', methods=['GET'])
@roles_required('officer', 'admin')
def get_officer_status():
    user = g.current_user
    counter = Counter.query.filter_by(assigned_officer_id=user.id, is_active=True).first()

    # If not assigned, allow selecting any active counter in their office
    if not counter:
        # Check if counter_id provided in query
        counter_id = request.args.get('counter_id', type=int)
        if counter_id:
            counter = Counter.query.get(counter_id)

    if not counter:
        available_counters = Counter.query.filter_by(is_active=True).all()
        return success_response({
            'counter': None,
            'available_counters': [c.to_dict() for c in available_counters],
            'current_token': None,
            'next_token': None,
            'waiting_count': 0
        }, "No counter currently assigned to officer", 200)

    # Current serving token at this counter
    current_token = Token.query.filter_by(
        counter_id=counter.id,
        status='SERVING'
    ).first()

    # Next token in line for this office
    next_token = Token.query.filter_by(
        office_id=counter.office_id,
        status='WAITING'
    ).order_by(Token.issued_at.asc()).first()

    waiting_count = Token.query.filter_by(
        office_id=counter.office_id,
        status='WAITING'
    ).count()

    # Calculate average service time of today's completed tokens
    completed_today = Token.query.filter(
        Token.counter_id == counter.id,
        Token.status == 'COMPLETED'
    ).all()

    avg_service_mins = 0
    if completed_today:
        durations = []
        for t in completed_today:
            if t.called_at and t.completed_at:
                durations.append((t.completed_at - t.called_at).total_seconds() / 60.0)
        if durations:
            avg_service_mins = round(sum(durations) / len(durations), 1)

    return success_response({
        'counter': counter.to_dict(),
        'current_token': current_token.to_dict() if current_token else None,
        'next_token': next_token.to_dict() if next_token else None,
        'waiting_count': waiting_count,
        'average_service_time': avg_service_mins or 4.5,
        'completed_today_count': len(completed_today)
    }, "Officer dashboard status retrieved", 200)

@officer_bp.route('/counter/assign', methods=['POST'])
@roles_required('officer', 'admin')
def assign_counter():
    data = request.get_json() or {}
    counter_id = data.get('counter_id')
    if not counter_id:
        return error_response("counter_id is required", "VALIDATION_ERROR", 400)

    counter = Counter.query.get(counter_id)
    if not counter:
        return error_response("Counter not found", "NOT_FOUND", 404)

    # Clear previous counter assignment
    old_counter = Counter.query.filter_by(assigned_officer_id=g.current_user.id).first()
    if old_counter and old_counter.id != counter.id:
        old_counter.assigned_officer_id = None

    counter.assigned_officer_id = g.current_user.id
    db.session.commit()

    return success_response(counter.to_dict(), "Counter assigned successfully", 200)

@officer_bp.route('/next', methods=['POST'])
@roles_required('officer', 'admin')
def call_next():
    data = request.get_json() or {}
    counter_id = data.get('counter_id')
    
    if not counter_id:
        counter = Counter.query.filter_by(assigned_officer_id=g.current_user.id).first()
        if counter:
            counter_id = counter.id

    if not counter_id:
        return error_response("Officer must have an assigned counter or provide counter_id", "COUNTER_REQUIRED", 400)

    service_id = data.get('service_id')
    token, err = call_next_token(g.current_user.id, counter_id, service_id)
    if err:
        return error_response(err, "CALL_NEXT_FAILED", 400)

    return success_response(token.to_dict(), f"Called token {token.token_number}", 200)

@officer_bp.route('/token/<int:token_id>/complete', methods=['POST'])
@roles_required('officer', 'admin')
def complete_token(token_id):
    token, err = complete_current_token(token_id, g.current_user.id)
    if err:
        return error_response(err, "COMPLETE_FAILED", 400)

    return success_response(token.to_dict(), f"Token {token.token_number} marked completed", 200)

@officer_bp.route('/token/<int:token_id>/skip', methods=['POST'])
@roles_required('officer', 'admin')
def skip_token(token_id):
    token, err = skip_current_token(token_id, g.current_user.id)
    if err:
        return error_response(err, "SKIP_FAILED", 400)

    return success_response(token.to_dict(), f"Token {token.token_number} marked skipped", 200)

@officer_bp.route('/token/<int:token_id>/recall', methods=['POST'])
@roles_required('officer', 'admin')
def recall_token(token_id):
    token, err = recall_current_token(token_id, g.current_user.id)
    if err:
        return error_response(err, "RECALL_FAILED", 400)

    return success_response(token.to_dict(), f"Token {token.token_number} re-called", 200)
