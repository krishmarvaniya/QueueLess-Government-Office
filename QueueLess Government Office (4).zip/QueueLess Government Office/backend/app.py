import os
import sys
import logging

# Ensure root workspace directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

from flask import Flask, send_from_directory, jsonify, request
from flask_socketio import join_room, leave_room
from sqlalchemy import text
from backend.config import Config
from backend.extensions import db, cors, socketio

# Import Blueprints
from backend.routes.auth import auth_bp
from backend.routes.offices import offices_bp
from backend.routes.services import services_bp
from backend.routes.tokens import tokens_bp
from backend.routes.queue import queue_bp
from backend.routes.officer import officer_bp
from backend.routes.admin import admin_bp
from backend.routes.prediction import prediction_bp
from backend.routes.notifications import notifications_bp
from backend.routes.reports import reports_bp

def create_app(config_class=Config):
    app = Flask(
        __name__,
        static_folder=config_class.STATIC_FOLDER,
        static_url_path=''
    )
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    cors.init_app(app, resources={r"/*": {"origins": "*"}})
    socketio.init_app(
        app,
        cors_allowed_origins="*",
        async_mode='threading',
        ping_timeout=25,
        ping_interval=10
    )

    # Register API Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(offices_bp)
    app.register_blueprint(services_bp)
    app.register_blueprint(tokens_bp)
    app.register_blueprint(queue_bp)
    app.register_blueprint(officer_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(prediction_bp)
    app.register_blueprint(notifications_bp)
    app.register_blueprint(reports_bp)

    # Health check endpoint
    @app.route('/api/health', methods=['GET'])
    def health_check():
        db_status = "disconnected"
        try:
            db.session.execute(text("SELECT 1"))
            db_status = "connected"
        except Exception as e:
            db_status = f"error: {str(e)}"

        return jsonify({
            'success': True,
            'status': 'healthy',
            'database': db_status,
            'version': '1.0.0'
        }), 200

    # ---------------- Frontend Routes ----------------
    @app.route('/')
    def serve_index():
        return send_from_directory(app.static_folder, 'index.html')

    @app.route('/<path:filename>')
    def serve_static_pages(filename):
        if filename.startswith('api/') or filename == 'api':
            return jsonify({'success': False, 'message': 'API endpoint not found', 'error': 'NOT_FOUND'}), 404
        file_path = os.path.join(app.static_folder, filename)
        if os.path.exists(file_path) and not os.path.isdir(file_path):
            return send_from_directory(app.static_folder, filename)
        # Try appending .html
        if os.path.exists(file_path + '.html'):
            return send_from_directory(app.static_folder, filename + '.html')
        # If directory has index.html
        if os.path.isdir(file_path) and os.path.exists(os.path.join(file_path, 'index.html')):
            return send_from_directory(file_path, 'index.html')
        return send_from_directory(app.static_folder, 'index.html')

    # API Error Handlers
    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith('/api/'):
            return jsonify({'success': False, 'message': 'API endpoint not found', 'error': 'NOT_FOUND'}), 404
        return send_from_directory(app.static_folder, 'index.html'), 404

    @app.errorhandler(500)
    def internal_error(e):
        if request.path.startswith('/api/'):
            return jsonify({'success': False, 'message': 'Internal server error occurred', 'error': 'SERVER_ERROR'}), 500
        return jsonify({'error': 'Internal server error'}), 500

    # ---------------- SocketIO Events ----------------
    @socketio.on('connect')
    def handle_connect():
        pass

    @socketio.on('join_office')
    def handle_join_office(data):
        office_id = data.get('office_id')
        if office_id:
            room = f"office_{office_id}"
            join_room(room)

    @socketio.on('leave_office')
    def handle_leave_office(data):
        office_id = data.get('office_id')
        if office_id:
            leave_room(f"office_{office_id}")

    @socketio.on('join_user')
    def handle_join_user(data):
        user_id = data.get('user_id')
        if user_id:
            join_room(f"user_{user_id}")

    @socketio.on('join_token')
    def handle_join_token(data):
        token_id = data.get('token_id')
        if token_id:
            join_room(f"token_{token_id}")

    return app

app = create_app()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"Starting QueueLess Government Office server on http://127.0.0.1:{port}")
    socketio.run(app, host='0.0.0.0', port=port, debug=True, allow_unsafe_werkzeug=True)
