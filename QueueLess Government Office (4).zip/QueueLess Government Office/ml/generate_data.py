import os
import random
import pandas as pd
import numpy as np

def generate_dataset(num_samples=2500, output_path="ml/dataset.csv"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    random.seed(42)
    np.random.seed(42)

    rows = []
    for _ in range(num_samples):
        active_counters = random.choice([1, 2, 3, 4, 5])
        avg_service_time = random.choice([10, 12, 15, 18, 20, 25, 30])
        queue_length = random.randint(0, 30)
        people_ahead = random.randint(0, max(0, queue_length))
        hour = random.randint(9, 17)
        day_of_week = random.randint(0, 6)

        # Base mathematical wait
        if active_counters > 0:
            base_wait = (people_ahead * avg_service_time) / active_counters
        else:
            base_wait = people_ahead * avg_service_time

        # Peak hours adjustment (11 AM to 2 PM gets slightly busier delays)
        time_factor = 1.15 if 11 <= hour <= 14 else 1.0
        
        # Monday & Friday factor
        day_factor = 1.1 if day_of_week in [0, 4] else 0.95

        # Stochastic noise (+/- 15%)
        noise = np.random.normal(0, 1.5)

        actual_wait = max(3.0, (base_wait * time_factor * day_factor) + noise)
        actual_wait = round(float(actual_wait), 1)

        rows.append({
            'queue_length': queue_length,
            'people_ahead': people_ahead,
            'active_counters': active_counters,
            'average_service_time': avg_service_time,
            'hour': hour,
            'day_of_week': day_of_week,
            'actual_wait': actual_wait
        })

    df = pd.DataFrame(rows)
    df.to_csv(output_path, index=False)
    print(f"Generated {len(df)} samples into {output_path}")

if __name__ == "__main__":
    generate_dataset()
