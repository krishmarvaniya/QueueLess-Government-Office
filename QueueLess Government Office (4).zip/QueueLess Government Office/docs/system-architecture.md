# QueueLess Government Office — System Architecture

## 1. High-Level Architecture Overview

QueueLess Government Office is an enterprise full-stack web platform built for digital government service centers. It replaces physical queues with a remote virtual token dispatching engine, real-time WebSocket state distribution, and machine-learning-driven waiting-time predictions.

```mermaid
flowchart TD
    subgraph ClientLayer ["Client Layer (HTML5 / Bootstrap 5 / JS ES6+)"]
        CP[Citizen Portal]
        OP[Officer Terminal]
        AP[Admin Command Center]
        QB[Public Display Board]
    end

    subgraph TransportLayer ["Real-Time & REST API Layer"]
        HTTP[REST APIs - Flask 3]
        WSS[WebSocket Transport - Flask-SocketIO]
    end

    subgraph ServiceLayer ["Application Logic Layer"]
        AUTH[Auth & RBAC Service]
        QUEUE[FIFO Queue Engine]
        TOKEN[Token & QR Generator]
        NOTIF[Notification Engine]
        PRED[ML Wait Prediction Service]
    end

    subgraph DataStorage ["Data & Model Storage"]
        DB[(MySQL Database)]
        MODEL[(RandomForestRegressor / model.pkl)]
    end

    CP -->|Fetch API| HTTP
    OP -->|Fetch API| HTTP
    AP -->|Fetch API| HTTP
    QB -->|WebSocket| WSS

    CP <-->|Socket.IO| WSS
    OP <-->|Socket.IO| WSS

    HTTP --> AUTH
    HTTP --> QUEUE
    HTTP --> TOKEN
    HTTP --> PRED

    QUEUE --> NOTIF
    QUEUE --> WSS
    TOKEN --> PRED
    PRED --> MODEL

    AUTH --> DB
    QUEUE --> DB
    TOKEN --> DB
    NOTIF --> DB
```

---

## 2. Component Specifications

### 2.1 Citizen Portal
- Allows citizens to register, authenticate, browse administrative offices, select services, inspect real-time waiting times, and issue virtual tokens.
- Generates a verifiable token pass complete with a scanned QR code and printable ticket.
- Real-time updates via Socket.IO push token status changes and arrival alert notifications without manual refreshes.

### 2.2 Officer Service Terminal
- Desk officers log in, claim active service counters, and call tokens using a dedicated calling board.
- Supported operations: **CALL NEXT**, **COMPLETE**, **SKIP**, and **RECALL**.
- Emits instantaneous WebSocket events to the entire facility and updates individual citizen token passes.

### 2.3 Admin Command Center
- Provides 8 real-time KPI metrics, interactive Chart.js visualizations (Token Status Breakdown, Service Popularity, Hourly Demand Load).
- Full management of administrative offices, operating hours, service catalogs, counters, user accounts, and immutable audit logs.
- Daily, weekly, and monthly performance reporting with CSV data export.

### 2.4 Machine Learning Prediction Engine
- Features: `queue_length`, `people_ahead`, `active_counters`, `average_service_time`, `hour`, `day_of_week`.
- Pipeline: Scikit-learn `RandomForestRegressor` with automatic fallback to `LinearRegression` and mathematical queue closed-form equations.
- Dynamic Arrival Window: Calculates recommended arrival time incorporating a configurable safety buffer (default: 10 minutes).
