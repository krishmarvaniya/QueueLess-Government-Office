# QueueLess Government Office — Deployment Guide

## 1. Production Deployment Prerequisites

- **Python**: 3.10, 3.11, 3.12, 3.13, or 3.14
- **Database**: MySQL 8.0+ or MariaDB 10.4+
- **WSGI / ASGI Server**: Gunicorn with Gevent / Threading worker
- **Reverse Proxy**: NGINX with WebSocket upgrade headers (`Upgrade $http_upgrade; Connection "upgrade"`)

---

## 2. Option A: Docker Compose Deployment (Recommended)

1. Clone or extract the repository onto the production server.
2. Update `.env` with strong production secrets:
   ```env
   SECRET_KEY=generate_strong_64_char_secret_key
   MYSQL_ROOT_PASSWORD=strong_production_db_password
   ```
3. Build and launch containers:
   ```bash
   docker-compose up -d --build
   ```
4. Verify running health check:
   ```bash
   curl http://localhost:5000/api/health
   ```

---

## 3. Option B: Virtual Machine / VPS Deployment (Ubuntu / Debian)

1. **Install MySQL & Python**:
   ```bash
   sudo apt update
   sudo apt install -y python3 python3-pip python3-venv mysql-server nginx
   ```
2. **Setup MySQL**:
   ```sql
   CREATE DATABASE queueless CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'queueless_user'@'localhost' IDENTIFIED BY 'StrongPassword123!';
   GRANT ALL PRIVILEGES ON queueless.* TO 'queueless_user'@'localhost';
   FLUSH PRIVILEGES;
   ```
3. **Import Schema & Seed**:
   ```bash
   mysql -u queueless_user -p queueless < database/schema.sql
   mysql -u queueless_user -p queueless < database/seed.sql
   ```
4. **Setup Virtual Environment & Install Requirements**:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r backend/requirements.txt
   python ml/train_model.py
   ```
5. **Systemd Service (`/etc/systemd/system/queueless.service`)**:
   ```ini
   [Unit]
   Description=QueueLess Government Office Application
   After=network.target

   [Service]
   User=www-data
   WorkingDirectory=/var/www/queueless
   ExecStart=/var/www/queueless/venv/bin/gunicorn --worker-class gthread --threads 4 -w 1 -b 127.0.0.1:5000 backend.app:app
   Restart=always

   [Install]
   WantedBy=multi-user.target
   ```
6. **NGINX Configuration**:
   ```nginx
   server {
       listen 80;
       server_name office.yourdomain.gov.in;

       location / {
           proxy_pass http://127.0.0.1:5000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection "upgrade";
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       }
   }
   ```

---

## 4. Option C: Cloud Deployment (Render, Railway, Fly.io)

- **Render**: Connect GitHub repository, choose Python environment, set build command to `pip install -r backend/requirements.txt && python ml/train_model.py`, and start command to `gunicorn --worker-class gthread --threads 4 -w 1 -b 0.0.0.0:$PORT backend.app:app`.
- **Database**: Add Managed MySQL add-on and supply `DATABASE_URL` environment variable.
